Phase1 / 候補9種レビュー用の公開派生パッケージ

試作 / NOT_SLICED / 全数印刷は保留。4 mm初回試作で小ささと穴詰まりの報告あり。
物理嵌合・保持力・全体組立は未確認。新案の採用・印刷指示ではありません。

ZIPを全て展開してください。FreeCADのassemblies/*.FCStdは隣のlibraries/を相対参照します。
artifacts/selected/r2-20260919/cad/assemblies/ を開き、libraries/は移動・改名しないでください。
Blenderは自己完結したメッシュを含みます。画像・動画・BOMの版を混同しないでください。
公開用に付随メタデータを整理しています。形状の再生成は行っていません。
当時の資料内のハッシュは当時の入力に対する記録です。現在のファイルはSHA256SUMS.txtで照合します。

公開記録: https://ktanino10.github.io/octoprints-brick-kit-downloads/
全ファイル目録: https://ktanino10.github.io/octoprints-brick-kit-downloads/archive/inventory.json
モデルはCC BY-NC 4.0。帰属・改変表示・ライセンスを維持してください。
GitHub / LEGOによる推奨・認証・互換性を示すものではありません。
